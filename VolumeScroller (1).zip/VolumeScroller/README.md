# Volume Scroller (system-wide)

Control your whole phone with the volume buttons, in any app. Built as an
Android accessibility service.

## Setup
1. Install the APK and open Volume Scroller.
2. Tap "Open Accessibility settings", find Volume Scroller, turn it on.
   If it is greyed out: Settings > Apps > Volume Scroller > three-dot menu >
   "Allow restricted settings", then try again.
3. Optional: add the "Volume Scroller" tile to Quick Settings to pause/resume.

## Modes (press BOTH volume buttons together to switch: 1, 2 or 3 pulses)
1. Scroll: Up/Down scrolls, hold = continuous, double-press = auto-scroll on/off
   (other button reverses direction)
2. Swipe: Up = previous (swipe right), Down = next (swipe left): photos, pages, carousels
3. System: Up = Back, Down = Home, double Up = Recents, double Down = Notifications

Haptics: light tick on each action, 1/2/3 pulses on mode change, one pulse for
auto-scroll on, two quick ticks for off. Speed slider and haptics toggle are in the app.

While active the buttons no longer change volume. Pause with the tile or the Active
checkbox. Normal volume returns during calls and on the lock screen.

## Build
GitHub Actions: Actions tab > Build APK > Run workflow (see .github/workflows/build.yml).
Or open in Android Studio and Build > Build APK(s).
