package com.example.volumescroller

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/** Gentle vibration patterns for the app's key events. */
class Haptics(context: Context) {

    private val vibrator: Vibrator =
        if (Build.VERSION.SDK_INT >= 31) {
            (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }

    var enabled = true

    private fun play(timings: LongArray, amplitudes: IntArray) {
        if (!enabled || !vibrator.hasVibrator()) return
        vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
    }

    /** Very light tick when a volume press starts an action. */
    fun scrollStart() = play(longArrayOf(0, 15), intArrayOf(0, 60))

    /** [count] soft pulses (1 = Scroll, 2 = Swipe, 3 = System) when the mode changes. */
    fun modeSwitch(count: Int) {
        val timings = mutableListOf(0L)
        val amps = mutableListOf(0)
        for (i in 0 until count) {
            if (i > 0) { timings.add(70L); amps.add(0) }
            timings.add(20L); amps.add(80)
        }
        play(timings.toLongArray(), amps.toIntArray())
    }

    /** One slightly longer pulse when auto-scroll turns on. */
    fun autoOn() = play(longArrayOf(0, 40), intArrayOf(0, 100))

    /** Two quick light ticks when auto-scroll turns off. */
    fun autoOff() = play(longArrayOf(0, 15, 50, 15), intArrayOf(0, 60, 0, 60))
}
