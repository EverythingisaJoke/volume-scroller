package com.example.volumescroller

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings tile that pauses / resumes the volume button control. */
class PauseTile : TileService() {

    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    override fun onStartListening() = refresh()

    override fun onClick() {
        prefs.edit().putBoolean("enabled", !prefs.getBoolean("enabled", true)).apply()
        refresh()
    }

    private fun refresh() {
        val tile = qsTile ?: return
        tile.state = if (prefs.getBoolean("enabled", true)) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.updateTile()
    }
}
