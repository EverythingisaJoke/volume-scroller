package com.example.volumescroller

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.accessibilityservice.GestureDescription.StrokeDescription
import android.app.KeyguardManager
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Path
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs

/**
 * System-wide volume button control.
 *
 * Modes (press BOTH volume buttons together to cycle):
 *  SCROLL - up/down scrolls, hold = continuous, double press = auto-scroll on/off
 *  SWIPE  - up = swipe right (previous), down = swipe left (next)
 *  SYSTEM - up = Back, down = Home, double up = Recents, double down = Notifications
 */
class VolumeControlService : AccessibilityService() {

    private enum class Mode { SCROLL, SWIPE, SYSTEM }

    private val handler = Handler(Looper.getMainLooper())
    private val prefs: SharedPreferences by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val haptics by lazy { Haptics(this) }

    private var mode = Mode.SCROLL

    // key state
    private val down = mutableSetOf<Int>()
    private var combo = false
    private var lastKey = -1
    private var lastDownTime = 0L
    private var pending: Runnable? = null

    // scrolling state (-1 = scroll up, +1 = scroll down)
    private var autoDir = 0
    private var holdDir = 0
    private var lastDir = 1
    private var chainActive = false
    private var stroke: StrokeDescription? = null
    private var fingerY = 0f

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() = stopAll()

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        stopAll()
        return super.onUnbind(intent)
    }

    // ---- Key handling ---------------------------------------------------------

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false

        if (!prefs.getBoolean("enabled", true) || shouldPassThrough()) {
            stopAll()
            return false // let Android handle the volume normally
        }
        haptics.enabled = prefs.getBoolean("haptics", true)

        val dir = if (code == KeyEvent.KEYCODE_VOLUME_UP) -1 else 1

        if (event.action == KeyEvent.ACTION_DOWN) {
            if (event.repeatCount == 0) {
                down.add(code)
                if (down.size >= 2) { // both buttons together: switch mode
                    cancelPending()
                    if (!combo) {
                        combo = true
                        cycleMode()
                    }
                    return true
                }
                if (combo) return true

                val isDouble = code == lastKey && event.eventTime - lastDownTime <= DOUBLE_MS
                if (isDouble) {
                    cancelPending()
                    lastKey = -1
                    onDouble(dir)
                } else {
                    lastKey = code
                    lastDownTime = event.eventTime
                    // Short delay lets us detect "both buttons"; System mode waits for a possible double.
                    val r = Runnable { pending = null; onSingle(dir) }
                    pending = r
                    handler.postDelayed(r, if (mode == Mode.SYSTEM) DOUBLE_MS else 70L)
                }
            } else if (!combo && mode == Mode.SCROLL && autoDir == 0) {
                if (event.repeatCount == 1) haptics.scrollStart()
                holdDir = dir
                ensureChain()
            }
        } else if (event.action == KeyEvent.ACTION_UP) {
            down.remove(code)
            if (down.isEmpty()) combo = false
            holdDir = 0 // the scroll chain winds itself down
        }
        return true
    }

    private fun shouldPassThrough(): Boolean {
        val keyguard = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return keyguard.isKeyguardLocked || audio.mode != AudioManager.MODE_NORMAL
    }

    private fun cancelPending() {
        pending?.let { handler.removeCallbacks(it) }
        pending = null
    }

    private fun stopAll() {
        cancelPending()
        autoDir = 0
        holdDir = 0
        down.clear()
        combo = false
    }

    private fun cycleMode() {
        autoDir = 0
        holdDir = 0
        mode = Mode.values()[(mode.ordinal + 1) % Mode.values().size]
        haptics.modeSwitch(mode.ordinal + 1)
    }

    private fun onSingle(dir: Int) {
        when (mode) {
            Mode.SCROLL -> if (autoDir == 0 && !chainActive) {
                haptics.scrollStart()
                val h = resources.displayMetrics.heightPixels
                val w = resources.displayMetrics.widthPixels
                // Scrolling down = finger moves up.
                val from = if (dir > 0) h * 0.72f else h * 0.28f
                val to = if (dir > 0) h * 0.28f else h * 0.72f
                swipe(w * 0.5f, from, w * 0.5f, to, 300L)
            }
            Mode.SWIPE -> {
                haptics.scrollStart()
                val h = resources.displayMetrics.heightPixels
                val w = resources.displayMetrics.widthPixels
                // Up = previous = finger moves right; Down = next = finger moves left.
                val from = if (dir < 0) w * 0.25f else w * 0.75f
                val to = if (dir < 0) w * 0.75f else w * 0.25f
                swipe(from, h * 0.5f, to, h * 0.5f, 180L)
            }
            Mode.SYSTEM -> {
                haptics.scrollStart()
                performGlobalAction(if (dir < 0) GLOBAL_ACTION_BACK else GLOBAL_ACTION_HOME)
            }
        }
    }

    private fun onDouble(dir: Int) {
        when (mode) {
            Mode.SCROLL -> {
                autoDir = if (autoDir == dir) 0 else dir
                if (autoDir != 0) {
                    haptics.autoOn()
                    ensureChain()
                } else {
                    haptics.autoOff()
                }
            }
            Mode.SWIPE -> onSingle(dir)
            Mode.SYSTEM -> {
                haptics.scrollStart()
                performGlobalAction(if (dir < 0) GLOBAL_ACTION_RECENTS else GLOBAL_ACTION_NOTIFICATIONS)
            }
        }
    }

    // ---- Gestures -------------------------------------------------------------

    private fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long) {
        val path = Path().apply {
            moveTo(x1, y1)
            lineTo(x2, y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun speedPx(): Float {
        val p = prefs.getInt("speed", 40)
        return (30 + p * 7) * resources.displayMetrics.density // px per second
    }

    private fun desiredDir() = if (autoDir != 0) autoDir else holdDir

    private fun startY(dir: Int): Float {
        val h = resources.displayMetrics.heightPixels
        return if (dir > 0) h * 0.78f else h * 0.22f
    }

    /**
     * Continuous scrolling: one long touch made of chained stroke segments, so the page
     * follows the "finger" smoothly with no fling. Runs while hold or auto-scroll is active.
     */
    private fun ensureChain() {
        if (chainActive) return
        val dir = desiredDir()
        if (dir == 0) return
        chainActive = true
        stroke = null
        lastDir = dir
        fingerY = startY(dir)
        nextSegment()
    }

    private fun nextSegment() {
        val dm = resources.displayMetrics
        val x = dm.widthPixels * 0.5f
        val minY = dm.heightPixels * 0.2f
        val maxY = dm.heightPixels * 0.8f

        val dir = desiredDir()
        if (dir != 0) lastDir = dir
        val stopping = dir == 0
        val duration = if (stopping) 30L else SEGMENT_MS

        // Scrolling down (dir > 0) moves the finger up (smaller y).
        var target = fingerY - lastDir * speedPx() * duration / 1000f
        var more = !stopping
        var restart = false
        if (target < minY || target > maxY) { // out of room: lift and start over
            target = target.coerceIn(minY, maxY)
            more = false
            restart = !stopping
        }
        if (abs(target - fingerY) < 1f) target = fingerY + 1f

        val path = Path().apply {
            moveTo(x, fingerY)
            lineTo(x, target)
        }
        val prev = stroke
        val seg = if (prev != null) prev.continueStroke(path, 0, duration, more)
        else StrokeDescription(path, 0, duration, more)

        val callback = object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription) {
                if (more) {
                    nextSegment()
                } else {
                    stroke = null
                    if (restart && desiredDir() != 0) {
                        fingerY = startY(desiredDir())
                        nextSegment()
                    } else {
                        chainActive = false
                    }
                }
            }

            override fun onCancelled(gestureDescription: GestureDescription) {
                stroke = null
                chainActive = false
            }
        }

        val ok = dispatchGesture(GestureDescription.Builder().addStroke(seg).build(), callback, handler)
        if (ok) {
            stroke = if (more) seg else null
            fingerY = target
        } else {
            stroke = null
            chainActive = false
        }
    }

    companion object {
        private const val DOUBLE_MS = 350L
        private const val SEGMENT_MS = 200L
    }
}
