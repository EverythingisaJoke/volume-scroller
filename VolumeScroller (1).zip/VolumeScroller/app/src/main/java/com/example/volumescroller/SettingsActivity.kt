package com.example.volumescroller

import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var activeCheck: CheckBox
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        statusText = findViewById(R.id.statusText)
        activeCheck = findViewById(R.id.activeCheck)
        val hapticsCheck: CheckBox = findViewById(R.id.hapticsCheck)
        val speedSeek: SeekBar = findViewById(R.id.speedSeek)
        val speedLabel: TextView = findViewById(R.id.speedLabel)

        findViewById<Button>(R.id.openAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        activeCheck.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("enabled", on).apply()
        }

        hapticsCheck.isChecked = prefs.getBoolean("haptics", true)
        hapticsCheck.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean("haptics", on).apply()
        }

        speedSeek.progress = prefs.getInt("speed", 40)
        speedLabel.text = "Speed: ${30 + speedSeek.progress * 7}"
        speedSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                speedLabel.text = "Speed: ${30 + progress * 7}"
                if (fromUser) prefs.edit().putInt("speed", progress).apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
    }

    override fun onResume() {
        super.onResume()
        activeCheck.isChecked = prefs.getBoolean("enabled", true) // the tile may have changed it
        statusText.text = if (isServiceOn()) {
            "Accessibility service is ON"
        } else {
            "Accessibility service is OFF. Turn it on in Accessibility settings."
        }
    }

    private fun isServiceOn(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val component = ComponentName(this, VolumeControlService::class.java)
        return enabled.contains(component.flattenToString()) ||
            enabled.contains(component.flattenToShortString())
    }
}
