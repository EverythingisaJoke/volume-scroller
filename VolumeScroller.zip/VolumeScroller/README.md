# Volume Scroller

A tiny browser that you control with the volume buttons.

## Controls

**Scroll mode (default)**
- Volume Up / Down: smooth scroll up / down one screen-ish
- Hold: continuous smooth scrolling
- Double-press a volume button: toggle auto-scroll in that direction
  (double-press the opposite button to reverse, same button to stop)
- Speed slider: sets hold and auto-scroll speed (remembered)

**Navigate mode** (tap the Mode button)
- Volume Up = back, Volume Down = forward through page history

**Options:** a Haptics checkbox turns vibration on/off. "Gallery keys" makes Navigate mode send left/right arrow keys to the page (photo galleries and lightboxes) instead of going back/forward in history.

**Haptics** (gentle vibration)
- light tick: a press starts scrolling or navigating
- two soft ticks: mode switch
- one pulse: auto-scroll on, two quick ticks: auto-scroll off

Volume keys are captured only while the app is open on screen (an Android limit).

## Get an APK

**Android Studio:** open this folder, then Build > Build APK(s).

**GitHub (no install needed):** push this folder to a new GitHub repo, open the
Actions tab, run "Build APK", then download `VolumeScroller-debug-apk`.
Transfer the .apk to your phone and allow "install unknown apps".
