package com.example.volumescroller

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var urlField: EditText
    private lateinit var modeButton: Button
    private lateinit var statusText: TextView
    private lateinit var speedLabel: TextView
    private lateinit var scroller: SmoothScroller
    private lateinit var haptics: Haptics

    /** false = Scroll mode, true = Navigate mode (volume = back / forward). */
    private var navMode = false
    private var galleryKeys = false

    private var lastKey = -1
    private var lastDownTime = 0L

    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        urlField = findViewById(R.id.urlField)
        modeButton = findViewById(R.id.modeButton)
        statusText = findViewById(R.id.statusText)
        speedLabel = findViewById(R.id.speedLabel)
        val speedSeek: SeekBar = findViewById(R.id.speedSeek)
        haptics = Haptics(this)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.builtInZoomControls = true
        webView.settings.displayZoomControls = false
        webView.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                if (!urlField.hasFocus()) urlField.setText(url)
            }
        }

        scroller = SmoothScroller(webView) {
            // Auto-scroll reached the end of the page.
            haptics.autoOff()
            updateStatus()
        }

        // Speed slider
        val saved = prefs.getInt("speed", 40)
        speedSeek.progress = saved
        applySpeed(saved)
        speedSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                applySpeed(progress)
                if (fromUser) prefs.edit().putInt("speed", progress).apply()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        // Haptics / gallery options
        val hapticsCheck: CheckBox = findViewById(R.id.hapticsCheck)
        val galleryCheck: CheckBox = findViewById(R.id.galleryCheck)
        haptics.enabled = prefs.getBoolean("haptics", true)
        hapticsCheck.isChecked = haptics.enabled
        hapticsCheck.setOnCheckedChangeListener { _, on ->
            haptics.enabled = on
            prefs.edit().putBoolean("haptics", on).apply()
        }
        galleryKeys = prefs.getBoolean("gallery", false)
        galleryCheck.isChecked = galleryKeys
        galleryCheck.setOnCheckedChangeListener { _, on ->
            galleryKeys = on
            prefs.edit().putBoolean("gallery", on).apply()
        }

        // Mode switch
        modeButton.setOnClickListener {
            navMode = !navMode
            if (navMode) {
                scroller.stopAll()
            }
            modeButton.text = if (navMode) "Mode: Navigate" else "Mode: Scroll"
            haptics.modeSwitch()
            updateStatus()
        }

        // Address bar
        findViewById<Button>(R.id.goButton).setOnClickListener { go() }
        urlField.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) { go(); true } else false
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        webView.loadUrl("https://duckduckgo.com")
        updateStatus()
    }

    // ---- Volume key handling -------------------------------------------------

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode != KeyEvent.KEYCODE_VOLUME_UP && keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) {
            return super.onKeyDown(keyCode, event)
        }
        // Volume up = up / back, volume down = down / forward.
        val dir = if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) -1 else 1

        if (event.repeatCount == 0) {
            val now = event.eventTime
            val isDouble = keyCode == lastKey && now - lastDownTime <= DOUBLE_PRESS_MS
            if (isDouble) {
                lastKey = -1 // a third quick press starts a fresh sequence
                onDoublePress(dir)
            } else {
                lastKey = keyCode
                lastDownTime = now
                onSinglePress(dir)
            }
        } else if (!navMode && !scroller.autoActive) {
            // Key is being held: continuous scroll.
            if (event.repeatCount == 1) haptics.scrollStart()
            scroller.startHold(dir)
        }
        return true // swallow so the system volume UI doesn't appear
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            scroller.stopHold()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    private fun onSinglePress(dir: Int) {
        if (navMode && galleryKeys) {
            haptics.scrollStart()
            sendArrowKey(if (dir < 0) "ArrowLeft" else "ArrowRight")
        } else if (navMode) {
            if (dir < 0 && webView.canGoBack()) {
                haptics.scrollStart()
                webView.goBack()
            } else if (dir > 0 && webView.canGoForward()) {
                haptics.scrollStart()
                webView.goForward()
            }
        } else if (!scroller.autoActive) {
            haptics.scrollStart()
            scroller.step(dir, webView.height * 0.7f)
        }
    }

    private fun onDoublePress(dir: Int) {
        if (navMode) {
            onSinglePress(dir) // behaves like two quick navigation presses
            return
        }
        val on = scroller.toggleAuto(dir)
        if (on) haptics.autoOn() else haptics.autoOff()
        updateStatus()
    }

    // ---- Helpers -------------------------------------------------------------

    /** Sends a key event to the page so photo galleries / lightboxes can flip images. */
    private fun sendArrowKey(key: String) {
        val code = if (key == "ArrowLeft") 37 else 39
        val js = "(function(){var o={key:'$key',code:'$key',keyCode:$code,which:$code,bubbles:true};" +
            "['keydown','keyup'].forEach(function(t){var e=new KeyboardEvent(t,o);" +
            "(document.activeElement||document.body).dispatchEvent(e);document.dispatchEvent(e);});})();"
        webView.evaluateJavascript(js, null)
    }

    private fun applySpeed(progress: Int) {
        val dpPerSec = 30 + progress * 7 // 30..730 dp per second
        scroller.speedPxPerSec = dpPerSec * resources.displayMetrics.density
        speedLabel.text = "Speed $dpPerSec"
    }

    private fun updateStatus() {
        statusText.text = when {
            navMode -> if (galleryKeys) "Vol up = previous photo, Vol down = next" else "Vol up = back, Vol down = forward"
            scroller.autoDirection < 0 -> "Auto-scroll ▲ on"
            scroller.autoDirection > 0 -> "Auto-scroll ▼ on"
            else -> "Auto-scroll off"
        }
        if (scroller.autoActive) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun go() {
        webView.loadUrl(normalize(urlField.text.toString()))
        urlField.clearFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(urlField.windowToken, 0)
    }

    private fun normalize(input: String): String {
        val t = input.trim()
        return when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(" ") || !t.contains(".") -> "https://duckduckgo.com/?q=" + Uri.encode(t)
            else -> "https://$t"
        }
    }

    override fun onPause() {
        super.onPause()
        scroller.stopAll()
        updateStatus()
    }

    companion object {
        private const val DOUBLE_PRESS_MS = 350L
    }
}
