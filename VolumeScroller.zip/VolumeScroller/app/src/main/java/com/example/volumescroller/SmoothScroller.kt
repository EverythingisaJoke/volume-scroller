package com.example.volumescroller

import android.view.Choreographer
import android.view.View
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sign

/**
 * Frame-synced smooth scrolling for a View (the WebView).
 *  - step():      eased scroll of a fixed distance (single volume press)
 *  - startHold(): continuous scroll while a key is held
 *  - toggleAuto(): continuous auto-scroll until toggled off or the page ends
 * Direction: -1 = up, +1 = down.
 */
class SmoothScroller(
    private val view: View,
    private val onAutoStopped: () -> Unit
) {
    var speedPxPerSec = 600f

    var autoDirection = 0
        private set
    val autoActive: Boolean get() = autoDirection != 0

    private var holdDirection = 0
    private var stepRemaining = 0f
    private var carry = 0f
    private var lastFrameNanos = 0L
    private var running = false
    private val choreographer = Choreographer.getInstance()
    private val callback = Choreographer.FrameCallback { now -> onFrame(now) }

    fun step(direction: Int, distancePx: Float) {
        stepRemaining += direction * distancePx
        start()
    }

    fun startHold(direction: Int) {
        holdDirection = direction
        start()
    }

    fun stopHold() {
        holdDirection = 0
    }

    /** Returns true if auto-scroll is now on. Same direction toggles off; opposite switches direction. */
    fun toggleAuto(direction: Int): Boolean {
        autoDirection = if (autoDirection == direction) 0 else direction
        stepRemaining = 0f
        if (autoActive) start()
        return autoActive
    }

    fun stopAll() {
        autoDirection = 0
        holdDirection = 0
        stepRemaining = 0f
    }

    private fun start() {
        if (running) return
        running = true
        lastFrameNanos = 0L
        choreographer.postFrameCallback(callback)
    }

    private fun onFrame(now: Long) {
        val dt = if (lastFrameNanos == 0L) 0f
        else ((now - lastFrameNanos) / 1_000_000_000f).coerceAtMost(0.05f)
        lastFrameNanos = now

        var dy = 0f
        when {
            autoDirection != 0 -> dy = autoDirection * speedPxPerSec * dt
            holdDirection != 0 -> dy = holdDirection * speedPxPerSec * dt
            stepRemaining != 0f -> {
                dy = stepRemaining * (1f - exp(-12f * dt)) // exponential ease-out
                stepRemaining -= dy
                if (abs(stepRemaining) < 1f) {
                    dy += stepRemaining
                    stepRemaining = 0f
                }
            }
            else -> {
                running = false
                carry = 0f
                lastFrameNanos = 0L
                return
            }
        }

        if (dy != 0f) {
            val dir = sign(dy).toInt()
            if (!view.canScrollVertically(dir)) {
                stepRemaining = 0f
                if (autoDirection != 0) {
                    autoDirection = 0
                    onAutoStopped()
                }
            } else {
                carry += dy
                val whole = carry.toInt()
                if (whole != 0) {
                    view.scrollBy(0, whole)
                    carry -= whole
                }
            }
        }
        choreographer.postFrameCallback(callback)
    }
}
